package com.uttam.placement_system.service;

import com.uttam.placement_system.model.Job;
import com.uttam.placement_system.model.Student;
import com.uttam.placement_system.repository.JobRepository;
import com.uttam.placement_system.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * SkillGapAnalyzerService
 * Compares a student's skills against job requirements and produces
 * a detailed gap report with match scores and learning recommendations.
 */
@Service
public class SkillGapAnalyzerService {

    @Autowired private StudentRepository studentRepo;
    @Autowired private JobRepository     jobRepo;
    @Autowired private ResumeParserService resumeParserService;

    // ─── Learning Resource Recommendations ───────────────────────────────────

    private static final Map<String, String> LEARNING_LINKS = new LinkedHashMap<>();
    static {
        LEARNING_LINKS.put("Java",             "https://docs.oracle.com/javase/tutorial/");
        LEARNING_LINKS.put("Python",           "https://docs.python.org/3/tutorial/");
        LEARNING_LINKS.put("JavaScript",       "https://javascript.info");
        LEARNING_LINKS.put("SQL",              "https://www.sqltutorial.org");
        LEARNING_LINKS.put("Machine Learning", "https://www.coursera.org/learn/machine-learning");
        LEARNING_LINKS.put("Cloud",            "https://aws.amazon.com/training/");
        LEARNING_LINKS.put("Docker/Kubernetes","https://docs.docker.com/get-started/");
        LEARNING_LINKS.put("Git",              "https://learngitbranching.js.org");
        LEARNING_LINKS.put("Data Structures",  "https://leetcode.com/explore/");
        LEARNING_LINKS.put("React",            "https://react.dev/learn");
        LEARNING_LINKS.put("Spring Boot",      "https://spring.io/guides");
        LEARNING_LINKS.put("REST API",         "https://restfulapi.net");
        LEARNING_LINKS.put("Android",          "https://developer.android.com/courses");
        LEARNING_LINKS.put("HTML/CSS",         "https://developer.mozilla.org/en-US/docs/Learn");
        LEARNING_LINKS.put("Linux",            "https://linuxjourney.com");
        LEARNING_LINKS.put("C++",              "https://www.learncpp.com");
        LEARNING_LINKS.put("MongoDB",          "https://learn.mongodb.com");
        LEARNING_LINKS.put("Testing",          "https://junit.org/junit5/docs/current/user-guide/");
    }

    // ─── Skill Importance Weights (for scoring) ───────────────────────────────

    private static final Map<String, Integer> SKILL_WEIGHTS = new LinkedHashMap<>();
    static {
        SKILL_WEIGHTS.put("Java", 3);
        SKILL_WEIGHTS.put("Python", 3);
        SKILL_WEIGHTS.put("JavaScript", 3);
        SKILL_WEIGHTS.put("SQL", 2);
        SKILL_WEIGHTS.put("Data Structures", 3);
        SKILL_WEIGHTS.put("Machine Learning", 3);
        SKILL_WEIGHTS.put("Cloud", 2);
        SKILL_WEIGHTS.put("Git", 1);
        SKILL_WEIGHTS.put("Docker/Kubernetes", 2);
        SKILL_WEIGHTS.put("REST API", 2);
    }

    // ─── Public API ───────────────────────────────────────────────────────────

    /**
     * Analyze skill gap between a student and a specific job.
     */
    public Map<String, Object> analyzeGapForJob(Long studentId, Long jobId) {
        Student student = studentRepo.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found"));
        Job job = jobRepo.findById(jobId)
                .orElseThrow(() -> new RuntimeException("Job not found"));

        Set<String> studentSkills = parseSkillSet(student.getSkills());
        Set<String> requiredSkills = parseSkillSet(job.getRequiredSkills());

        return buildGapReport(studentSkills, requiredSkills, job.getRole(), student.getName());
    }

    /**
     * Analyze skill gap between a student's parsed resume skills and a specific job.
     * Used after resume parsing — skills come from the parsed resume, not DB profile.
     */
    public Map<String, Object> analyzeGapFromParsedSkills(
            List<String> parsedSkills, Long jobId, String studentName) {

        Job job = jobRepo.findById(jobId)
                .orElseThrow(() -> new RuntimeException("Job not found"));

        Set<String> studentSkills = new HashSet<>(parsedSkills);
        Set<String> requiredSkills = parseSkillSet(job.getRequiredSkills());

        return buildGapReport(studentSkills, requiredSkills, job.getRole(), studentName);
    }

    /**
     * Full profile analysis: compare student's skills against ALL active jobs.
     * Returns top-N best matching jobs + gap for each.
     */
    public Map<String, Object> analyzeProfileGap(Long studentId) {
        Student student = studentRepo.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found"));

        Set<String> studentSkills = parseSkillSet(student.getSkills());

        List<Job> activeJobs = jobRepo.findByStatusAndTpoApproved(Job.JobStatus.ACTIVE, true);

        List<Map<String, Object>> jobReports = new ArrayList<>();
        for (Job job : activeJobs) {
            Set<String> required = parseSkillSet(job.getRequiredSkills());
            if (required.isEmpty()) continue;

            Map<String, Object> report = buildGapReport(studentSkills, required, job.getRole(), student.getName());
            report.put("jobId",      job.getId());
            report.put("jobRole",    job.getRole());
            report.put("company",    job.getCompany() != null ? job.getCompany().getName() : "N/A");
            report.put("ctc",        job.getCtc());
            jobReports.add(report);
        }

        // Sort by match score descending
        jobReports.sort((a, b) ->
                Double.compare((double) b.get("matchScore"), (double) a.get("matchScore")));

        // Overall skill strength
        Map<String, Object> profile = new LinkedHashMap<>();
        profile.put("studentName",      student.getName());
        profile.put("currentSkills",    new ArrayList<>(studentSkills));
        profile.put("totalSkills",      studentSkills.size());
        profile.put("skillStrengthPct", computeStrengthPct(studentSkills));
        profile.put("topJobMatches",    jobReports.stream().limit(5).collect(Collectors.toList()));
        profile.put("allJobsAnalyzed",  jobReports.size());
        profile.put("recommendations",  getTopRecommendations(studentSkills, activeJobs));

        return profile;
    }

    /**
     * Quick skill gap for a student against manually supplied skill list.
     * Used by frontend to compare resume-parsed skills vs any skill set.
     */
    public Map<String, Object> quickGap(List<String> studentSkills, List<String> requiredSkills) {
        return buildGapReport(new HashSet<>(studentSkills), new HashSet<>(requiredSkills), "Custom Role", "Student");
    }

    // ─── Core Builder ─────────────────────────────────────────────────────────

    private Map<String, Object> buildGapReport(
            Set<String> studentSkills,
            Set<String> requiredSkills,
            String jobRole,
            String studentName) {

        // Normalize to lowercase comparison
        Map<String, String> studentNorm = normalizeSkillMap(studentSkills);
        Map<String, String> requiredNorm = normalizeSkillMap(requiredSkills);

        List<String> matched = new ArrayList<>();
        List<Map<String, String>> missing = new ArrayList<>();

        for (Map.Entry<String, String> req : requiredNorm.entrySet()) {
            if (studentNorm.containsKey(req.getKey())) {
                matched.add(req.getValue());   // original casing
            } else {
                Map<String, String> m = new LinkedHashMap<>();
                m.put("skill",    req.getValue());
                m.put("priority", getPriority(req.getValue()));
                m.put("learnUrl", LEARNING_LINKS.getOrDefault(req.getValue(), "https://www.google.com/search?q=learn+" + req.getValue()));
                missing.add(m);
            }
        }

        // Sort missing: HIGH priority first
        missing.sort(Comparator.comparing(m -> priorityOrder(m.get("priority"))));

        // Compute weighted match score
        double matchScore = computeMatchScore(studentSkills, requiredSkills);
        String matchGrade = scoreToGrade(matchScore);

        Map<String, Object> report = new LinkedHashMap<>();
        report.put("studentName",    studentName);
        report.put("jobRole",        jobRole);
        report.put("matchScore",     Math.round(matchScore * 10.0) / 10.0);
        report.put("matchGrade",     matchGrade);
        report.put("totalRequired",  requiredSkills.size());
        report.put("matchedCount",   matched.size());
        report.put("missingCount",   missing.size());
        report.put("matchedSkills",  matched);
        report.put("missingSkills",  missing);
        report.put("extraSkills",    getExtraSkills(studentSkills, requiredSkills));
        report.put("readinessLevel", getReadinessLevel(matchScore));
        report.put("summary",        buildSummary(matched.size(), missing.size(), matchScore, jobRole));

        return report;
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private Set<String> parseSkillSet(String skills) {
        if (skills == null || skills.isBlank()) return new HashSet<>();
        return Arrays.stream(skills.split("[,;|\\n]+"))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toCollection(LinkedHashSet::new));
    }

    /** Return a lowercase-keyed map for case-insensitive comparison */
    private Map<String, String> normalizeSkillMap(Set<String> skills) {
        Map<String, String> m = new LinkedHashMap<>();
        for (String s : skills) m.put(s.toLowerCase().trim(), s.trim());
        return m;
    }

    private double computeMatchScore(Set<String> student, Set<String> required) {
        if (required.isEmpty()) return 100.0;
        int weightedMatch = 0, totalWeight = 0;
        for (String req : required) {
            int w = SKILL_WEIGHTS.getOrDefault(req, 1);
            totalWeight += w;
            boolean has = student.stream().anyMatch(s -> s.equalsIgnoreCase(req));
            if (has) weightedMatch += w;
        }
        return totalWeight == 0 ? 0 : (weightedMatch * 100.0 / totalWeight);
    }

    private double computeStrengthPct(Set<String> skills) {
        int total = SKILL_WEIGHTS.values().stream().mapToInt(Integer::intValue).sum();
        int own = skills.stream()
                .mapToInt(s -> SKILL_WEIGHTS.getOrDefault(s, 1))
                .sum();
        return Math.min(100.0, Math.round((own * 100.0 / total) * 10.0) / 10.0);
    }

    private String scoreToGrade(double score) {
        if (score >= 90) return "A+";
        if (score >= 80) return "A";
        if (score >= 70) return "B+";
        if (score >= 60) return "B";
        if (score >= 50) return "C";
        if (score >= 30) return "D";
        return "F";
    }

    private String getReadinessLevel(double score) {
        if (score >= 80) return "Ready to Apply";
        if (score >= 60) return "Almost Ready";
        if (score >= 40) return "Needs Preparation";
        return "Significant Skill Gap";
    }

    private String getPriority(String skill) {
        int w = SKILL_WEIGHTS.getOrDefault(skill, 1);
        if (w >= 3) return "HIGH";
        if (w == 2) return "MEDIUM";
        return "LOW";
    }

    private int priorityOrder(String p) {
        return switch (p) { case "HIGH" -> 0; case "MEDIUM" -> 1; default -> 2; };
    }

    private List<String> getExtraSkills(Set<String> student, Set<String> required) {
        Set<String> reqLower = required.stream().map(String::toLowerCase).collect(Collectors.toSet());
        return student.stream()
                .filter(s -> !reqLower.contains(s.toLowerCase()))
                .collect(Collectors.toList());
    }

    private String buildSummary(int matched, int missing, double score, String role) {
        if (score >= 80)
            return "Excellent match for " + role + "! You have " + matched + " of the required skills. You're ready to apply.";
        if (score >= 60)
            return "Good match for " + role + "! You have " + matched + " of the required skills. Learn " + missing + " more skill(s) to boost your chances.";
        if (score >= 40)
            return "Partial match for " + role + ". Focus on acquiring " + missing + " missing skill(s) to improve eligibility.";
        return "Significant gap for " + role + ". Building " + missing + " skill(s) will substantially improve your placement prospects.";
    }

    private List<Map<String, String>> getTopRecommendations(Set<String> studentSkills, List<Job> jobs) {
        // Count how often each missing skill appears across all jobs
        Map<String, Integer> freq = new LinkedHashMap<>();
        for (Job job : jobs) {
            Set<String> req = parseSkillSet(job.getRequiredSkills());
            for (String s : req) {
                boolean has = studentSkills.stream().anyMatch(ss -> ss.equalsIgnoreCase(s));
                if (!has) freq.merge(s, 1, Integer::sum);
            }
        }
        return freq.entrySet().stream()
                .sorted((a, b) -> b.getValue() - a.getValue())
                .limit(8)
                .map(e -> {
                    Map<String, String> r = new LinkedHashMap<>();
                    r.put("skill",     e.getKey());
                    r.put("demandedBy", e.getValue() + " job(s)");
                    r.put("priority",  getPriority(e.getKey()));
                    r.put("learnUrl",  LEARNING_LINKS.getOrDefault(e.getKey(), "https://www.google.com/search?q=learn+" + e.getKey()));
                    return r;
                })
                .collect(Collectors.toList());
    }
}