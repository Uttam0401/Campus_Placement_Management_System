package com.uttam.placement_system.service;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.*;
import java.util.regex.*;
import java.util.stream.Collectors;

/**
 * ResumeParserService
 * Parses a PDF resume using Apache PDFBox, then applies
 * Java Regex + keyword matching to extract structured fields.
 */
@Service
public class ResumeParserService {

    // ─── Regex Patterns ──────────────────────────────────────────────────────

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("[a-zA-Z0-9._%+\\-]+@[a-zA-Z0-9.\\-]+\\.[a-zA-Z]{2,}");

    private static final Pattern PHONE_PATTERN =
            Pattern.compile("(?:(?:\\+91|0)?[\\s\\-]?)?[6-9]\\d{9}");

    private static final Pattern CGPA_PATTERN =
            Pattern.compile("(?i)(?:cgpa|gpa|score)[\\s:]*([0-9](?:\\.[0-9]{1,2})?)(?:/10)?");

    private static final Pattern CGPA_FALLBACK =
            Pattern.compile("([0-9]\\.[0-9]{1,2})\\s*/\\s*10");

    private static final Pattern GRADUATION_YEAR_PATTERN =
            Pattern.compile("(?i)(?:batch|graduating|graduation|pass(?:out|ing)?|year)[\\s:]*(?:of[\\s:]*)?(?:20)?(2[0-9])\\b");

    private static final Pattern YEAR_4DIGIT_PATTERN =
            Pattern.compile("\\b(20[2-3][0-9])\\b");

    private static final Pattern LINKEDIN_PATTERN =
            Pattern.compile("(?i)(?:https?://)?(?:www\\.)?linkedin\\.com/in/[a-zA-Z0-9_\\-]+");

    private static final Pattern NAME_LINE_PATTERN =
            Pattern.compile("^([A-Z][a-z]+(?:\\s+[A-Z][a-z]+){1,3})$", Pattern.MULTILINE);

    // ─── Skill Keyword Dictionaries ───────────────────────────────────────────

    private static final Map<String, List<String>> SKILL_KEYWORDS = new LinkedHashMap<>();

    static {
        SKILL_KEYWORDS.put("Java",           List.of("java", "spring boot", "spring", "hibernate", "jpa", "maven", "gradle", "j2ee"));
        SKILL_KEYWORDS.put("Python",         List.of("python", "django", "flask", "fastapi", "pandas", "numpy", "scikit", "tensorflow", "pytorch", "keras"));
        SKILL_KEYWORDS.put("JavaScript",     List.of("javascript", "js", "node.js", "nodejs", "react", "reactjs", "vue", "vuejs", "angular", "typescript", "express", "next.js"));
        SKILL_KEYWORDS.put("C++",            List.of("c++", "cpp", "stl", "competitive programming"));
        SKILL_KEYWORDS.put("C",              List.of("\\bc\\b", "c language", "c programming"));
        SKILL_KEYWORDS.put("SQL",            List.of("sql", "mysql", "postgresql", "oracle", "sqlite", "pl/sql", "t-sql", "database"));
        SKILL_KEYWORDS.put("MongoDB",        List.of("mongodb", "mongoose", "nosql", "mongo"));
        SKILL_KEYWORDS.put("HTML/CSS",       List.of("html", "css", "html5", "css3", "bootstrap", "tailwind", "sass", "scss"));
        SKILL_KEYWORDS.put("Machine Learning", List.of("machine learning", "ml", "deep learning", "neural network", "nlp", "data science", "ai", "artificial intelligence"));
        SKILL_KEYWORDS.put("Cloud",          List.of("aws", "azure", "gcp", "google cloud", "ec2", "s3", "lambda", "cloud computing", "heroku"));
        SKILL_KEYWORDS.put("Docker/Kubernetes", List.of("docker", "kubernetes", "k8s", "container", "microservice"));
        SKILL_KEYWORDS.put("Git",            List.of("git", "github", "gitlab", "bitbucket", "version control"));
        SKILL_KEYWORDS.put("Linux",          List.of("linux", "unix", "bash", "shell scripting", "ubuntu", "centos"));
        SKILL_KEYWORDS.put("Android",        List.of("android", "kotlin", "android studio", "mobile development"));
        SKILL_KEYWORDS.put("Data Structures", List.of("data structures", "algorithms", "dsa", "leetcode", "competitive programming"));
        SKILL_KEYWORDS.put("REST API",       List.of("rest", "restful", "api", "soap", "graphql", "postman", "swagger"));
        SKILL_KEYWORDS.put("Redux",          List.of("redux", "mobx", "state management", "context api"));
        SKILL_KEYWORDS.put("Testing",        List.of("junit", "mockito", "jest", "selenium", "unit test", "integration test", "tdd"));
        SKILL_KEYWORDS.put("PHP",            List.of("php", "laravel", "codeigniter", "wordpress", "composer"));
        SKILL_KEYWORDS.put("Ruby",           List.of("ruby", "rails", "ruby on rails"));
    }

    // ─── Section Headers ──────────────────────────────────────────────────────

    private static final List<String> SKILL_SECTION_HEADERS = List.of(
            "skills", "technical skills", "key skills", "core competencies",
            "technologies", "tech stack", "programming languages", "tools", "expertise"
    );

    private static final List<String> EDUCATION_SECTION_HEADERS = List.of(
            "education", "academic", "qualification", "degree"
    );

    private static final List<String> EXPERIENCE_SECTION_HEADERS = List.of(
            "experience", "internship", "work", "employment", "projects", "project"
    );

    // ─── Public API ───────────────────────────────────────────────────────────

    /**
     * Parse a resume PDF file and return structured data.
     */
    public Map<String, Object> parseResume(MultipartFile file) throws IOException {
        String rawText = extractTextFromPdf(file);
        return parseResumeText(rawText);
    }

    /**
     * Parse resume from a file path (already saved on disk).
     */
    public Map<String, Object> parseResumeFromPath(java.io.File pdfFile) throws IOException {
        String rawText = extractTextFromFile(pdfFile);
        return parseResumeText(rawText);
    }

    // ─── Text Extraction ──────────────────────────────────────────────────────

    private String extractTextFromPdf(MultipartFile file) throws IOException {
        // PDFBox 3.x: Loader.loadPDF() replaces PDDocument.load()
        // Must use byte array — Loader does not accept InputStream directly
        try (PDDocument doc = Loader.loadPDF(file.getBytes())) {
            PDFTextStripper stripper = new PDFTextStripper();
            stripper.setSortByPosition(true);
            return stripper.getText(doc);
        }
    }

    private String extractTextFromFile(java.io.File file) throws IOException {
        // PDFBox 3.x: Loader.loadPDF(File) replaces PDDocument.load(File)
        try (PDDocument doc = Loader.loadPDF(file)) {
            PDFTextStripper stripper = new PDFTextStripper();
            stripper.setSortByPosition(true);
            return stripper.getText(doc);
        }
    }

    // ─── Core Parser ─────────────────────────────────────────────────────────

    public Map<String, Object> parseResumeText(String text) {
        Map<String, Object> result = new LinkedHashMap<>();

        result.put("rawTextLength",   text.length());
        result.put("name",            extractName(text));
        result.put("email",           extractEmail(text));
        result.put("phone",           extractPhone(text));
        result.put("cgpa",            extractCgpa(text));
        result.put("graduationYear",  extractGraduationYear(text));
        result.put("linkedinUrl",     extractLinkedin(text));
        result.put("skills",          extractSkills(text));
        result.put("skillsRaw",       extractSkillsSectionRaw(text));
        result.put("education",       extractEducationSection(text));
        result.put("experience",      extractExperienceSection(text));
        result.put("wordCount",       countWords(text));

        return result;
    }

    // ─── Field Extractors ─────────────────────────────────────────────────────

    private String extractName(String text) {
        // Heuristic: first non-empty line that looks like a name (Title Case OR ALL CAPS words, no digits)
        String[] lines = text.split("\\r?\\n");
        for (String line : lines) {
            line = line.trim();
            if (line.isEmpty()) continue;
            if (line.length() > 50) continue;         // too long for a name
            if (line.matches(".*\\d.*")) continue;    // contains digits
            if (line.matches(".*[@|#<>].*")) continue;
            // Title Case: e.g. "Uttam Kumar"
            if (line.matches("[A-Z][a-zA-Z]+(?:\\s+[A-Z][a-zA-Z]+){1,3}")) {
                return toTitleCase(line);
            }
            // ALL CAPS: e.g. "UTTAM KUMAR" or "UTTAM KUMAR SINGH"
            if (line.matches("[A-Z]{2,}(?:\\s+[A-Z]{2,}){1,3}")) {
                return toTitleCase(line);
            }
        }
        // Fallback: regex scan
        Matcher m = NAME_LINE_PATTERN.matcher(text);
        if (m.find()) return m.group(1);
        return null;
    }

    private String toTitleCase(String name) {
        String[] words = name.toLowerCase().split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (String word : words) {
            if (!word.isEmpty()) {
                if (sb.length() > 0) sb.append(" ");
                sb.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
            }
        }
        return sb.toString();
    }

    private String extractEmail(String text) {
        Matcher m = EMAIL_PATTERN.matcher(text);
        return m.find() ? m.group().toLowerCase() : null;
    }

    private String extractPhone(String text) {
        Matcher m = PHONE_PATTERN.matcher(text.replaceAll("[\\s\\-]", ""));
        return m.find() ? m.group() : null;
    }

    private Double extractCgpa(String text) {
        Matcher m = CGPA_PATTERN.matcher(text);
        if (m.find()) {
            try { return Double.parseDouble(m.group(1)); } catch (NumberFormatException ignored) {}
        }
        m = CGPA_FALLBACK.matcher(text);
        if (m.find()) {
            try { return Double.parseDouble(m.group(1)); } catch (NumberFormatException ignored) {}
        }
        return null;
    }

    private Integer extractGraduationYear(String text) {
        Matcher m = GRADUATION_YEAR_PATTERN.matcher(text);
        if (m.find()) {
            try {
                String yr = m.group(1);
                return yr.length() == 2 ? 2000 + Integer.parseInt(yr) : Integer.parseInt(yr);
            } catch (NumberFormatException ignored) {}
        }
        // Find 4-digit years between 2023–2030 (future grad years)
        m = YEAR_4DIGIT_PATTERN.matcher(text);
        List<Integer> years = new ArrayList<>();
        while (m.find()) {
            int y = Integer.parseInt(m.group(1));
            if (y >= 2023 && y <= 2030) years.add(y);
        }
        if (!years.isEmpty()) {
            return Collections.max(years); // most recent/future year is likely graduation
        }
        return null;
    }

    private String extractLinkedin(String text) {
        Matcher m = LINKEDIN_PATTERN.matcher(text);
        if (!m.find()) return null;
        String url = m.group();
        if (!url.startsWith("http")) url = "https://" + url;
        return url;
    }

    /**
     * Keyword matching: scan the full text for known skill keywords,
     * return a comma-separated string of matched skills.
     */
    public List<String> extractSkills(String text) {
        String lower = text.toLowerCase();
        List<String> found = new ArrayList<>();

        for (Map.Entry<String, List<String>> entry : SKILL_KEYWORDS.entrySet()) {
            String skill = entry.getKey();
            for (String kw : entry.getValue()) {
                // Use word-boundary regex for each keyword
                String regex = "\\b" + Pattern.quote(kw) + "\\b";
                if (Pattern.compile(regex).matcher(lower).find()) {
                    found.add(skill);
                    break; // already matched this skill category
                }
            }
        }
        return found;
    }

    private String extractSkillsSectionRaw(String text) {
        return extractSection(text, SKILL_SECTION_HEADERS, 500);
    }

    private String extractEducationSection(String text) {
        return extractSection(text, EDUCATION_SECTION_HEADERS, 600);
    }

    private String extractExperienceSection(String text) {
        return extractSection(text, EXPERIENCE_SECTION_HEADERS, 800);
    }

    /**
     * Generic section extractor: finds the first matching section header,
     * then returns up to maxChars of content until the next section.
     */
    private String extractSection(String text, List<String> headers, int maxChars) {
        String lower = text.toLowerCase();
        int start = -1;
        for (String header : headers) {
            // Match header line (ignoring surrounding whitespace/colons)
            Pattern p = Pattern.compile("(?m)^[\\s]*" + Pattern.quote(header) + "[\\s:]*$",
                    Pattern.CASE_INSENSITIVE);
            Matcher m = p.matcher(lower);
            if (m.find()) { start = m.end(); break; }
        }
        if (start < 0) return null;

        // Find where the next section begins
        Pattern nextSection = Pattern.compile(
                "(?m)^[\\s]*(?:education|experience|skills|projects|certifications|awards|" +
                        "achievements|summary|objective|contact|references|internship|work|employment)[\\s:]*$",
                Pattern.CASE_INSENSITIVE);
        Matcher ns = nextSection.matcher(text);
        int end = text.length();
        while (ns.find()) {
            if (ns.start() > start) { end = ns.start(); break; }
        }

        String section = text.substring(start, Math.min(end, start + maxChars)).trim();
        // Remove excessive blank lines
        return section.replaceAll("(?m)^\\s*$\\n", "").trim();
    }

    private int countWords(String text) {
        if (text == null || text.isBlank()) return 0;
        return text.trim().split("\\s+").length;
    }
}