package com.uttam.placement_system;

import com.uttam.placement_system.model.Company;
import com.uttam.placement_system.model.Student;
import com.uttam.placement_system.model.Tpo;
import com.uttam.placement_system.repository.CompanyRepository;
import com.uttam.placement_system.repository.StudentRepository;
import com.uttam.placement_system.repository.TpoRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataInitializer {

    @Bean
    public CommandLineRunner seedTestData(
            StudentRepository studentRepo,
            CompanyRepository companyRepo,
            TpoRepository tpoRepo,
            PasswordEncoder passwordEncoder) {

        return args -> {

            final String PASS = "Test@1234";

            // ── DEFAULT TPO ADMIN ──────────────────────────────────────
            // Login: tpo@saitm.ac.in  /  admin123
            if (!tpoRepo.existsByEmail("tpo@saitm.ac.in")) {
                Tpo tpo = new Tpo();
                tpo.setName("Dr. Uttam Kumar");
                tpo.setEmail("tpo@saitm.ac.in");
                tpo.setPassword(passwordEncoder.encode("admin123"));
                tpo.setPhone("9876543210");
                tpo.setDesignation("Placement Officer");
                tpoRepo.save(tpo);
            } // else: TPO already exists — do NOT reset password on restart

            // ── TEST STUDENTS ──────────────────────────────────────────

            if (!studentRepo.existsByEmail("rahul.sharma@saitm.ac.in")) {
                Student s1 = new Student();
                s1.setName("Rahul Sharma");
                s1.setEmail("rahul.sharma@saitm.ac.in");
                s1.setPassword(passwordEncoder.encode(PASS));
                s1.setPhone("9000000001");
                s1.setBranch("CSE");
                s1.setCgpa(8.5);
                s1.setGraduationYear(2025);
                s1.setSkills("Java, Spring Boot, React, SQL, Git");
                s1.setApprovalStatus(Student.ApprovalStatus.APPROVED);
                studentRepo.save(s1);
            } // else: already exists — skip

            if (!studentRepo.existsByEmail("priya.verma@saitm.ac.in")) {
                Student s2 = new Student();
                s2.setName("Priya Verma");
                s2.setEmail("priya.verma@saitm.ac.in");
                s2.setPassword(passwordEncoder.encode(PASS));
                s2.setPhone("9000000002");
                s2.setBranch("IT");
                s2.setCgpa(7.8);
                s2.setGraduationYear(2025);
                s2.setSkills("Python, Data Analysis, SQL, Machine Learning");
                s2.setApprovalStatus(Student.ApprovalStatus.APPROVED);
                studentRepo.save(s2);
            } // else: already exists — skip

            if (!studentRepo.existsByEmail("amit.gupta@saitm.ac.in")) {
                Student s3 = new Student();
                s3.setName("Amit Gupta");
                s3.setEmail("amit.gupta@saitm.ac.in");
                s3.setPassword(passwordEncoder.encode(PASS));
                s3.setPhone("9000000003");
                s3.setBranch("ECE");
                s3.setCgpa(6.9);
                s3.setGraduationYear(2025);
                s3.setSkills("C++, Embedded Systems, MATLAB");
                s3.setApprovalStatus(Student.ApprovalStatus.APPROVED);
                studentRepo.save(s3);
            } // else: already exists — skip

            // ── TEST COMPANIES ─────────────────────────────────────────

            if (!companyRepo.existsByEmail("hr@techcorp.com")) {
                Company c1 = new Company();
                c1.setName("TechCorp Solutions");
                c1.setEmail("hr@techcorp.com");
                c1.setPassword(passwordEncoder.encode(PASS));
                c1.setIndustry("Information Technology");
                c1.setHrName("Priya Sharma");
                c1.setPhone("9123456789");
                c1.setLocation("Bangalore");
                c1.setApprovalStatus(Company.ApprovalStatus.APPROVED);
                companyRepo.save(c1);
            } // else: already exists — skip

            if (!companyRepo.existsByEmail("campus@infosys.com")) {
                Company c2 = new Company();
                c2.setName("Infosys Limited");
                c2.setEmail("campus@infosys.com");
                c2.setPassword(passwordEncoder.encode(PASS));
                c2.setIndustry("IT Services");
                c2.setHrName("Amit Patel");
                c2.setPhone("9234567890");
                c2.setLocation("Pune");
                c2.setApprovalStatus(Company.ApprovalStatus.APPROVED);
                companyRepo.save(c2);
            } // else: already exists — skip

            if (!companyRepo.existsByEmail("hr@testcorp.com")) {
                Company c3 = new Company();
                c3.setName("TestCorp Pvt Ltd");
                c3.setEmail("hr@testcorp.com");
                c3.setPassword(passwordEncoder.encode(PASS));
                c3.setIndustry("Information Technology");
                c3.setHrName("Test HR");
                c3.setPhone("9000000099");
                c3.setLocation("Delhi");
                c3.setApprovalStatus(Company.ApprovalStatus.APPROVED);
                companyRepo.save(c3);
            } // else: already exists — skip

            System.out.println("====================================================");
            System.out.println("  TEST ACCOUNTS READY");
            System.out.println("  TPO Admin:");
            System.out.println("    tpo@saitm.ac.in  /  admin123");
            System.out.println("  Students  (password: " + PASS + "):");
            System.out.println("    rahul.sharma@saitm.ac.in");
            System.out.println("    priya.verma@saitm.ac.in");
            System.out.println("    amit.gupta@saitm.ac.in");
            System.out.println("  Companies (password: " + PASS + "):");
            System.out.println("    hr@techcorp.com");
            System.out.println("    campus@infosys.com");
            System.out.println("    hr@testcorp.com");
            System.out.println("====================================================");
        };
    }
}