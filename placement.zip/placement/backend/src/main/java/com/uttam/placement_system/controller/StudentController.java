package com.uttam.placement_system.controller;

import com.uttam.placement_system.service.ResumeParserService;
import com.uttam.placement_system.service.SkillGapAnalyzerService;
import com.uttam.placement_system.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/student")
@CrossOrigin(origins = "*")
public class StudentController {

    @Autowired private StudentService        studentService;
    @Autowired private ResumeParserService   resumeParserService;
    @Autowired private SkillGapAnalyzerService skillGapService;

    private Long userId(Authentication auth) { return (Long) auth.getCredentials(); }

    // ───────────────────────── DASHBOARD / PROFILE ──────────────────────────

    @GetMapping("/dashboard")
    public ResponseEntity<?> dashboard(Authentication auth) {
        try { return ResponseEntity.ok(studentService.getDashboardStats(userId(auth))); }
        catch (Exception e) { return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); }
    }

    @GetMapping("/profile")
    public ResponseEntity<?> getProfile(Authentication auth) {
        try { return ResponseEntity.ok(studentService.getProfile(userId(auth))); }
        catch (Exception e) { return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); }
    }

    @PutMapping("/profile")
    public ResponseEntity<?> updateProfile(Authentication auth, @RequestBody Map<String, Object> body) {
        try { return ResponseEntity.ok(studentService.updateProfile(userId(auth), body)); }
        catch (Exception e) { return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); }
    }

    // ───────────────────────── RESUME UPLOAD (BUG FIX) ──────────────────────
    // BUG FIX: Frontend sends FormData with key "file" AND "resume".
    //          Accept both via @RequestParam so either works.

    @PostMapping("/resume")
    public ResponseEntity<?> uploadResume(
            Authentication auth,
            @RequestParam(value = "file", required = false) MultipartFile fileParam,
            @RequestParam(value = "resume", required = false) MultipartFile resumeParam) {
        try {
            // Accept whichever param name the client sends
            MultipartFile file = (fileParam != null) ? fileParam : resumeParam;
            if (file == null || file.isEmpty())
                return ResponseEntity.badRequest().body(Map.of("error", "No file provided"));

            String url = studentService.uploadResume(userId(auth), file);
            return ResponseEntity.ok(Map.of("resumeUrl", url, "message", "Resume uploaded successfully"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    // ───────────────────────── RESUME PARSER ────────────────────────────────

    /**
     * Upload + parse a resume in one step.
     * Extracts: name, email, phone, CGPA, graduation year, LinkedIn, skills.
     * Also saves the file and auto-fills the student's skills field.
     */
    @PostMapping("/resume/parse")
    public ResponseEntity<?> parseResume(
            Authentication auth,
            @RequestParam(value = "file", required = false) MultipartFile fileParam,
            @RequestParam(value = "resume", required = false) MultipartFile resumeParam) {
        try {
            MultipartFile file = (fileParam != null) ? fileParam : resumeParam;
            if (file == null || file.isEmpty())
                return ResponseEntity.badRequest().body(Map.of("error", "No file provided"));

            // 1. Parse the resume
            Map<String, Object> parsed = resumeParserService.parseResume(file);

            // 2. Save the file (upload)
            String url = studentService.uploadResume(userId(auth), file);
            parsed.put("resumeUrl", url);

            // 3. Auto-update skills in profile if skills were detected
            @SuppressWarnings("unchecked")
            List<String> skills = (List<String>) parsed.get("skills");
            if (skills != null && !skills.isEmpty()) {
                String skillsCsv = String.join(", ", skills);
                studentService.updateProfile(userId(auth), Map.of("skills", skillsCsv));
                parsed.put("skillsAutoApplied", true);
            }

            // 4. Auto-fill CGPA if detected and profile doesn't have one
            if (parsed.get("cgpa") != null) {
                var student = studentService.getProfile(userId(auth));
                if (student.getCgpa() == null) {
                    studentService.updateProfile(userId(auth), Map.of("cgpa", parsed.get("cgpa")));
                    parsed.put("cgpaAutoApplied", true);
                }
            }

            return ResponseEntity.ok(parsed);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    // ───────────────────────── SKILL GAP ANALYZER ───────────────────────────

    /**
     * Full profile skill gap: compare student skills vs all active jobs.
     * Returns top job matches, missing skills, and learning recommendations.
     */
    @GetMapping("/skill-gap")
    public ResponseEntity<?> skillGapProfile(Authentication auth) {
        try { return ResponseEntity.ok(skillGapService.analyzeProfileGap(userId(auth))); }
        catch (Exception e) { return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); }
    }

    /**
     * Skill gap for a specific job.
     * Returns matched, missing skills + match score (0–100) + grade.
     */
    @GetMapping("/skill-gap/job/{jobId}")
    public ResponseEntity<?> skillGapForJob(Authentication auth, @PathVariable Long jobId) {
        try { return ResponseEntity.ok(skillGapService.analyzeGapForJob(userId(auth), jobId)); }
        catch (Exception e) { return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); }
    }

    /**
     * Quick skill gap — accepts student skill list + required skill list directly.
     * Useful for frontend to compute gap after resume parsing without saving.
     */
    @PostMapping("/skill-gap/quick")
    public ResponseEntity<?> quickSkillGap(@RequestBody Map<String, Object> body) {
        try {
            @SuppressWarnings("unchecked")
            List<String> student  = (List<String>) body.get("studentSkills");
            @SuppressWarnings("unchecked")
            List<String> required = (List<String>) body.get("requiredSkills");
            if (student == null || required == null)
                return ResponseEntity.badRequest().body(Map.of("error", "studentSkills and requiredSkills are required"));
            return ResponseEntity.ok(skillGapService.quickGap(student, required));
        } catch (Exception e) { return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); }
    }

    // ───────────────────────── JOBS ─────────────────────────────────────────

    @GetMapping("/jobs")
    public ResponseEntity<?> getAllJobs() {
        try { return ResponseEntity.ok(studentService.getAllActiveJobs()); }
        catch (Exception e) { return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); }
    }

    @GetMapping("/jobs/eligible")
    public ResponseEntity<?> getEligibleJobs(Authentication auth) {
        try { return ResponseEntity.ok(studentService.getEligibleJobs(userId(auth))); }
        catch (Exception e) { return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); }
    }

    @GetMapping("/jobs/{jobId}/eligibility")
    public ResponseEntity<?> checkEligibility(Authentication auth, @PathVariable Long jobId) {
        try { return ResponseEntity.ok(studentService.checkEligibility(userId(auth), jobId)); }
        catch (Exception e) { return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); }
    }

    @PostMapping("/apply")
    public ResponseEntity<?> applyForJob(Authentication auth, @RequestBody Map<String, Object> body) {
        try {
            Long jobId = Long.parseLong(body.get("jobId").toString());
            String coverLetter = (String) body.get("coverLetter");
            return ResponseEntity.ok(studentService.applyForJob(userId(auth), jobId, coverLetter));
        } catch (Exception e) { return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); }
    }

    @GetMapping("/applications")
    public ResponseEntity<?> getMyApplications(Authentication auth) {
        try { return ResponseEntity.ok(studentService.getMyApplications(userId(auth))); }
        catch (Exception e) { return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); }
    }

    @PostMapping("/photo")
    public ResponseEntity<?> uploadPhoto(Authentication auth,
                                         @RequestParam("photo") MultipartFile photo) {
        try { return ResponseEntity.ok(studentService.uploadPhoto(userId(auth), photo)); }
        catch (Exception e) { return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); }
    }
}