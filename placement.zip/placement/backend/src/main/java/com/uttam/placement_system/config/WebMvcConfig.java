package com.uttam.placement_system.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * WebMvcConfig
 *
 * 1. Serves uploaded files (resumes, photos) via /uploads/**
 *
 * 2. Serves the entire frontend/ folder via /placement/**
 *    so the app runs fully on http://localhost:8080
 *
 *    Access pages at:
 *      http://localhost:8080/placement/auth/login.html
 *      http://localhost:8080/placement/student/dashboard.html
 *      http://localhost:8080/placement/tpo/dashboard.html
 *      http://localhost:8080/placement/company/dashboard.html
 *
 * NOTE: For these resource handlers to work, /placement/** and /uploads/**
 * must be permitted in SecurityConfig. Without that, Spring Security
 * returns 404 before this config is ever consulted.
 */
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    @Value("${app.upload.dir}")
    private String uploadDir;

    /**
     * Optional explicit frontend path in application.properties.
     * Leave blank (app.frontend.dir=) to use auto-detection.
     */
    @Value("${app.frontend.dir:}")
    private String frontendDir;

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {

        // ── 1. Uploaded files (/uploads/**) ───────────────────────────────
        String uploadLocation = uploadDir.replace("\\", "/");
        if (!uploadLocation.endsWith("/")) uploadLocation += "/";
        registry.addResourceHandler("/uploads/**")
                .addResourceLocations("file:" + uploadLocation);

        // ── 2. Frontend static files (/placement/**) ──────────────────────
        String frontendLocation = resolveFrontendLocation();

        registry.addResourceHandler("/placement/**")
                .addResourceLocations(frontendLocation)
                .setCachePeriod(0);  // no caching during development

        System.out.println("[WebMvcConfig] Serving frontend from: " + frontendLocation);
    }

    /**
     * Resolves the absolute path to the frontend/ folder.
     *
     * Priority order:
     *   1. app.frontend.dir property (if set and the directory exists)
     *   2. Sibling /frontend/ folder relative to the working directory
     *      (works whether launched from /backend or the project root)
     */
    private String resolveFrontendLocation() {

        // ── Option 1: explicitly configured path ──────────────────────────
        if (frontendDir != null && !frontendDir.isBlank()) {
            String loc = frontendDir.replace("\\", "/");
            if (!loc.endsWith("/")) loc += "/";
            Path p = Paths.get(frontendDir);
            if (Files.isDirectory(p)) {
                return "file:" + loc;
            }
            // Configured path doesn't exist — fall through to auto-detect
            System.err.println("[WebMvcConfig] WARNING: app.frontend.dir does not exist: "
                    + frontendDir + " — falling back to auto-detect.");
        }

        // ── Option 2: auto-detect relative to working directory ───────────
        // IntelliJ runs the backend module with CWD = .../placement/backend
        // Maven/jar run from project root has CWD = .../placement
        String cwd = Paths.get("").toAbsolutePath().toString().replace("\\", "/");

        // If running from inside the backend sub-folder, go one level up
        if (cwd.endsWith("/backend")) {
            cwd = cwd.substring(0, cwd.length() - "/backend".length());
        }

        return "file:" + cwd + "/frontend/";
    }
}